<?php
require_once ('dat/datos.php');
/**
 *  Devuelve true si el código del usuario y contraseña se 
 *  encuentra en la tabla de usuarios
 *  @param $login : Código de usuario
 *  @param $clave : Clave del usuario
 *  @return true o false
 */
function userOk($login,$clave):bool {
    
    global $usuarios;

    foreach($usuarios as $usuario => $valor){
        if($usuario == $login && $valor[1] == $clave){

            $resultado = true;
            break;

        }else{

            $resultado=false;

        }
    }

    return $resultado;
}

/**
 *  Devuelve el rol asociado al usuario
 *  @param $login: código de usuario
 *  @return ROL_ALUMNO o ROL_PROFESOR
 */
function getUserRol($login){

    global $usuarios;

    foreach($usuarios as $usuario => $valor){

        if($usuario == $login){

        return $valor[2];
        break;

        }
    }
}

/**
 *  Muestra las notas del alumno indicado.
 *  @param $codigo: Código del usuario
 *  @return $devuelve una cadena con una tabla html con los resultados 
 */
function verNotasAlumno($codigo):String{

    $msg="";
    global $nombreModulos;
    global $notas;
    global $usuarios;

        foreach($usuarios as $clave => $valor){

            if($clave == $codigo){

                $msg .= " Bienvenido/a alumno/a: ". $valor[0];

            }
        
        $msg .= "<table>";

            $msg .= "<tr>";

            for($i=0;$i<count($nombreModulos);$i++){        //mostrar nombre de las asignaturas

                    $msg .= "<th>" . $nombreModulos[$i] . "</th>";

            }
            
            $msg .= "</tr>";

            $msg .= "<tr>";

                foreach($notas as $clave => $nota){     //mostrar la nota de las asignaturas

                    if($clave == $codigo){

                        for($i=0;$i<4;$i++){

                            $msg .= "<td>" . $nota[$i] . "</td>";

                        }

                    }
                }


            break;

        }

            $msg .= "</tr>";
        
        $msg .= "</table>";

    

    return $msg;
}

/**
 *  Muestra las notas de todos alumnos. 
 *  @param $codigo: Código del profesor
 *  @return $devuelve una cadena con una tabla html con los resultados 
 */
function verNotaTodas ($codigo): String {
    $msg="";
    global $nombreModulos;
    global $notas;
    global $usuarios;

    foreach($usuarios as $clave => $valor){     //mostrar el nombre del profesor

        if($clave == $codigo){

            $msg .= " Bienvenido Profesor: " . $valor[0];
            break;

        }
    }

    $msg .= "<table>";

        $msg .= "<tr>";

        $msg .= "<th> Nombre </th>";

        for($i=0;$i<count($nombreModulos);$i++){        //obtener los nombres de las asignaturas

            $msg .= "<th>" . $nombreModulos[$i] . "</th>";

        }
            
        $msg .= "</tr>";

        foreach($notas as $claves => $nota){        //obtener el nombre de los alumn@s

            $msg .= "<tr>";

                foreach($usuarios as $clave => $valor){

                    if($claves == $clave){

                        $msg .= "<td>" . $valor[0] . "</td>";
                        break;

                    }
                }

                    for($i=0;$i<4;$i++){        //imprimir las notas de alumn@s en tabla

                        $msg .= "<td>" . $nota[$i] . "</td>";
                            
                    }

            $msg .= "</tr>";

        }

    $msg .= "</table>";
    return $msg;
}