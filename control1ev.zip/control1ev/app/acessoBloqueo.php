<html>
<head>
<meta charset="UTF-8">
<link href="web/default.css" rel="stylesheet" type="text/css" />
<title>NOTAS</title>
</head>
<body>
<div id="container" style="width: 600px;">
<div id="header">
<h1>ACCESO DE NOTAS</h1>
</div>
<div id="content">
<p>SUPERADO EL NIVEL DE FALLOS</p>

</div>
</div>
</body>
</html>