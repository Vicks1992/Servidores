<?php
function usuarioOk($usuario, $contraseña) :bool {

   $uLimpio=trim($usuario);

   $cLimpio=trim($contraseña);

   $numeroUsuario=strlen($uLimpio);

   $otraContraseña=strrev($uLimpio);   //el nombre "usuario" al revés

   if($numeroUsuario >= 8 && $contraseña == $otraContraseña){

      return true;

   }
  
   return false;
    
}

function contarPalabras($comentario): int{

   $texto=trim($comentario);

   $array=preg_split("/[\s,;]+/",$texto);  //separa palabras por espacios, comas y puntos.

   $conteo=count($array);

   return $conteo;

}

function letraRepetida($comentario): string {

   $cadena=trim($comentario);

   $array=str_split($cadena);

   $conteo=array_count_values($array);

   arsort($conteo);

   foreach($conteo as $clave => $valor){

      $letra=$clave;

      break;

   }
   
   return $letra;

}

function palabra($comentario): string {

   $cadena=trim($comentario);

   $array=preg_split("/[\s,;]+/",$cadena);

   $conteo=array_count_values($array);

   arsort($conteo);

   $max=1;

   foreach($conteo as $clave => $valor){

      if($clave>$max){

         return $max=$clave;
         
      }else{
            
         return "No hay palabra repetida";

      }

   }

}
