<?php


class Producto      //siempre será el mismo esquema
{
    private $codigo;
    private $nombre;
    private $stock;
    private $stock_min;
    private $precio;
    
    // Getter con método mágico
    public function __get($atributo){
        if(property_exists($this, $atributo)) {
            return $this->$atributo;
        }
    }
    // Setter con método mágico
    public function __set($atributo,mixed $valor){
        if(property_exists($this, $atributo)) {
            $this->$atributo = $valor;
        }
    }
    
}
