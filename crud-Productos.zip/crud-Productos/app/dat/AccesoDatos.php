<?php
include_once "app/dat/Producto.php";    //para conectar la clase
include_once "app/config.php";      //para conectar la base de datos

/*
 * Acceso a datos con BD Usuarios y Patrón Singleton 
 * Un único objeto para la clase
 * VERSION 1:  las sentencias precompiladas ser crean en cada función
 */
class AccesoDatos { //no tocar
    
    private static $modelo = null;
    private $dbh = null;
    
    
    public static function getModelo(){
        // Si no existe lo crea el acceso de a la BD
        if (self::$modelo == null){
            self::$modelo = new AccesoDatos();
        }
        return self::$modelo;
    }
    
    

   // Constructor privado  Patron singleton, se accede por getModelo
   
    private function __construct(){     //conectar con la base de datos
        
        try {
            $dsn = "mysql:host=".SERVER_DB.";dbname=".DATABASE.";charset=utf8";
            // Creo el objeto PDO estableciendo la conexión a la BD
            $this->dbh = new PDO($dsn,DB_USER,DB_PASSWD);
            // Si falla genera una excepción
            $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e){
            echo "Error de conexión ".$e->getMessage();
            exit();
        }   
    }

    // Cierro la conexión anulando todos los objectos relacioanado con la conexión PDO (stmt)
    public static function closeModelo(){   //no tocar
        if (self::$modelo != null){
            $obj = self::$modelo;
            $obj->dbh = null;     // Cierro la conexión
            self::$modelo = null; // Borro el objeto.
        }
    }


    // Devuelvo un array de objeto de Usuarios
    public function getProductos ():array {     //conectar con la tabla de la DB
        $tproductos = [];
        // Sobre la conexión PDO prepara la consulta;
        $stmt_producto = $this->dbh->prepare("SELECT * FROM productos");
        // Los resultados se devuelven como objetos de la clase Usuarios
        $stmt_producto->setFetchMode(PDO::FETCH_CLASS, 'Producto');     //conectar con la Clase
        
        // Ejecuto la sentencias 
        if ( $stmt_producto->execute() ){
            //$tuser = $stmt_usuarios->fetchAll();
            // Mientra $user no sea false, sea un objeto
            while ( $producto = $stmt_producto->fetch()){
               // añado ese objeto a la tabla
               $tproductos[]= $producto;
            }
        }
        

        return $tproductos;
    }
    
    // Devuelvo un usuario o false
    public function getProducto (String $codigo) {      //Para mostrar productos de la Clase
        $producto = false;
        $stmt_producto   = $this->dbh->prepare("select * from productos where codigo=:codigo");
        $stmt_producto->setFetchMode(PDO::FETCH_CLASS, 'Producto');
        $stmt_producto->bindParam(':codigo', $codigo);
        if ( $stmt_producto->execute() ){
             // Solo hay un objeto
             if ( $obj = $stmt_producto->fetch()){
                $producto= $obj;
            }
        }
        return $producto;
    }
    
    // UPDATE
    public function modProducto($producto):bool{    //Modificaciones de la tabla
      
        $stmt_modproductos   = $this->dbh->prepare("update productos set nombre=:nombre, stock=:stock, stock_min=:stock_min, precio=:precio where codigo=:codigo");
        $stmt_modproductos->bindValue(':login',$producto->codigo);
        $stmt_modproductos->bindValue(':nombre',$producto->nombre);
        $stmt_modproductos->bindValue(':stock',$producto->stock);
        $stmt_modproductos->bindValue(':stock_min',$producto->stock_min);
        $stmt_modproductos->bindValue(':precio', $producto->precio);
        $stmt_modproductos->execute();
        // El número de filas modificadas debe ser 1
        $resu = ($stmt_modproductos->rowCount () == 1);     //al modificar, devuelve 1
        return $resu;
    }

    //INSERT
    public function addProducto($producto):bool{        //ingresar 1 producto a la tabla
        $stmt_creaproducto  = $this->dbh->prepare("insert into productos (codigo,nombre,stock,stock_min,precio) Values(?,?,?,?,?)");
        //$stmt_creauser->bindValue(1,$user->login);
        $stmt_creaproducto->execute( [$producto->codigo, $producto->nombre, $producto->stock, $producto->stock_min, $producto->precio]);
        $resu = ($stmt_creaproducto->rowCount () == 1);     //al añadir, devuelve 1
        return $resu;
    }

    //DELETE
    public function borrarProducto(String $codigo):bool {
        $stmt_borproducto = $this->dbh->prepare("delete from productos where codigo =:codigo");
        $stmt_borproducto->bindValue(':codigo', $codigo);
        $stmt_borproducto->execute();
        $resu = ($stmt_borproducto->rowCount () == 1);  //devuelve 1 si lo borra
        return $resu;
    }   
    
     // Evito que se pueda clonar el objeto. (SINGLETON)
    public function __clone()
    { 
        trigger_error('La clonación no permitida', E_USER_ERROR); 
    }
}

